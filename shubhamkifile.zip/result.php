<?php
$host = 'localhost';
$username = 'root';
$password = 'door';
$database = 'registration_database';

// Create a database connection
$connection = new mysqli($host, $username, $password, $database);

// Check the connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (isset($_GET['rollno'])) {
    $rollno = $_GET['rollno'];
    $query = "SELECT * FROM third_year WHERE rollno = $rollno";
    $result = $connection->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $studentName = $row['name'];
        $WT = $row['WT'];
        $DBMS = $row['DBMS'];
        $CN = $row['CN'];
        $HCI = $row['HCI'];
        $TOC = $row['TOC'];
        $SGPA = $row['SGPA'];
        
    } else {
        $studentName = "Unknown";
        $WT = $DBMS = $CN = $HCI = $TOC = "N/A";
    }
} else {
    $studentName = "Roll No not provided.";
    $WT = $DBMS = $CN = $HCI = $TOC = "N/A";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Details</title>
    <link rel="stylesheet" type="text/css" href="result_style.css">
</head>
<body>
    
  <div class="table-container">
  <table>
    <thead>
      <tr>
        <td colspan="5">TE SEM 5</td>
      </tr>
      <tr>
        <td colspan="3">Name: <?php echo $studentName; ?></td>
        <td colspan="2">RollNo: <?php echo $rollno; ?></td>
      </tr>
      <tr>
        <td>Code</td>
        <td colspan="2">Name</td>
        <td rowspan="2">Credits</td>
        <td>Marks</td>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>310245D</td>
        <td colspan="2">Human Computer Interface</td>
        <td>3.0</td>
        <td><?php echo $HCI; ?></td>
      </tr>
      <tr>
        <td>310242</td>
        <td colspan="2">Theory of Computation</td>
        <td>3.0</td>
        <td><?php echo $TOC; ?></td>
      </tr>
      <tr>
        <td>310241</td>
        <td colspan="2">Database Management System</td>
        <td>3.0</td>
        <td><?php echo $DBMS; ?></td>
      </tr>
      <tr>
        <td>317521</td>
        <td colspan="2">Computer Network</td>
        <td>3.0</td>
        <td><?php echo $CN; ?></td>
      </tr>
      <tr>
        <td>310252</td>
        <td colspan="2">Web Technology</td>
        <td>3.0</td>
        <td><?php echo $WT; ?></td>
      </tr>
    </tbody>
    <tfoot>
      <tr>
        <td colspan="4" class="footer">Grade</td>
        <td>15.0</td>
      </tr>
      <tr>
        <td colspan="4" class="footer">SGPA</td>
         <td><?php echo $SGPA; ?></td>
      </tr>
    </tfoot>
  </table>
</div>
</body>
</html>
